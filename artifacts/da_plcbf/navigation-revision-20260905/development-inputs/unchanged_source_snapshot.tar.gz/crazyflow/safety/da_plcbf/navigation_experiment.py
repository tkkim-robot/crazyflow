"""Matched navigation with exogenous worlds and obstacle-free persistent learning.

The actor/learner receives proprioception and the same declared point model as the frozen
controller. Waypoints and predicted obstacle paths remain inside task control and safety.
Deterministic runs record an exogenous update schedule and actual synchronized service costs;
they are mechanism experiments, never claims of real-time availability.
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any

import jax
import jax.numpy as jnp
import numpy as np

from crazyflow.safety.da_plcbf.continuous_version_a import (
    ContinuousVersionAConfig,
    PolicyRollouts,
    continuous_version_a_step,
    rollout_waypoint_library,
)
from crazyflow.safety.da_plcbf.deterministic_schedule import DeterministicUpdateSchedule
from crazyflow.safety.da_plcbf.learner_checkpoint import (
    load_learner_checkpoint,
    save_learner_checkpoint,
)
from crazyflow.safety.da_plcbf.mujoco_comparison_video import ComparisonVideoTrace, ObstacleTrack
from crazyflow.safety.da_plcbf.navigation_audit import audit_navigation_execution
from crazyflow.safety.da_plcbf.navigation_world import (
    NavigationWorld,
    WaypointProgress,
    advance_waypoints,
    nominal_encounter_metrics,
)
from crazyflow.safety.da_plcbf.online_constant_wind import (
    OnlineConstantWindResult,
    _append_method_record,
    _empty_method_records,
    _method_trace,
    _timing_statistics,
    save_online_constant_wind_result,
)
from crazyflow.safety.da_plcbf.persistent_skill_learner import (
    build_persistent_skill_learner,
    rollout_skill_library,
)
from crazyflow.safety.da_plcbf.point_wind_estimator import (
    PointWindEstimatorConfig,
    initialize_point_wind_estimator,
    model_with_point_wind,
    update_point_wind_estimator,
)
from crazyflow.safety.da_plcbf.quad_policy import QuadPolicyConfig
from crazyflow.safety.da_plcbf.quad_rollouts import direct_wrench_symplectic_step
from crazyflow.safety.da_plcbf.selector import SelectionConfig
from crazyflow.safety.da_plcbf.version_a_barriers import VersionABarrierConfig
from crazyflow.safety.da_plcbf.version_a_filter import VersionAFilterConfig


@dataclass(frozen=True, slots=True)
class NavigationExperimentConfig:
    model_information: str = "oracle"
    estimator_response_rate: float = 2.4
    learning_start_seconds: float = 4.0
    update_every_controls: int = 2
    enable_learning: bool = True
    learner_kind: str = "reference"
    nominal_acceleration_limit: float = 1.2
    probe_every_controls: int = 25
    save_periodic_snapshots_controls: int = 100

    def validate(self, world: NavigationWorld) -> None:
        if self.model_information not in {"oracle", "estimated"}:
            raise ValueError("model information must be oracle or estimated wind")
        if self.learner_kind not in {"reference", "original"}:
            raise ValueError("unknown learner kind")
        for name in (
            "update_every_controls",
            "probe_every_controls",
            "save_periodic_snapshots_controls",
        ):
            if type(getattr(self, name)) is not int or getattr(self, name) < 1:
                raise ValueError(f"{name} must be a positive integer")
        if (
            not np.isfinite(self.learning_start_seconds)
            or self.learning_start_seconds < 0
            or not np.isclose(
                self.learning_start_seconds / world.config.control_period,
                round(self.learning_start_seconds / world.config.control_period),
            )
        ):
            raise ValueError("learning start must be a nonnegative control boundary")
        if not all(
            np.isfinite(value) and value > 0
            for value in (self.estimator_response_rate, self.nominal_acceleration_limit)
        ):
            raise ValueError("estimator rate and nominal authority must be positive finite")
        if type(self.enable_learning) is not bool:
            raise ValueError("enable_learning must be boolean")
        # The current video model represents one exact centered box and a constant enclosure.
        if len(world.config.payload_events) > 1:
            raise ValueError(
                "the recorded navigation renderer currently supports one payload attachment"
            )
        if any(
            np.linalg.norm(event.half_extents) > world.config.ego_radius
            for event in world.config.payload_events
        ):
            raise ValueError(
                "this experiment requires payload geometry inside the original enclosure"
            )


def build_navigation_controller(
    world: NavigationWorld, bundle: Any, config: NavigationExperimentConfig
) -> Any:
    """The only function in this experiment that combines tasks with safety geometry."""
    policy_config = bundle.config
    if policy_config.control_interval_steps != world.config.control_interval_steps:
        raise ValueError("checkpoint command cadence must equal the executed command hold")
    if policy_config.dt != world.config.dt:
        raise ValueError("checkpoint and world integration steps differ")
    safety = world.safety_limits()
    barrier = VersionABarrierConfig(
        obstacle_clearance=world.config.obstacle_clearance,
        arena_clearance=0.08,
        ego_radius=world.config.ego_radius,
    )
    runtime = ContinuousVersionAConfig(
        dt=policy_config.dt,
        horizon=policy_config.horizon,
        obstacle_clearance=world.config.obstacle_clearance,
        ego_radius=world.config.ego_radius,
        control_interval_steps=world.config.control_interval_steps,
        prefer_nominal_when_safe=False,
    )
    nominal_config = QuadPolicyConfig(acceleration_limit=config.nominal_acceleration_limit)

    @jax.jit
    def controller(
        state: Any, params: Any, model: Any, obstacles: Any, previous: Any, goal: Any
    ) -> Any:
        def nominal(candidate: Any, point: Any) -> PolicyRollouts:
            return rollout_waypoint_library(
                candidate,
                goal[None],
                jnp.zeros((1, 3)),
                point,
                bundle.actuator,
                nominal_config,
                dt=policy_config.dt,
                horizon=policy_config.horizon,
                position_gain=2.0,
                velocity_gain=2.8,
                model_compensation=True,
                command_hold_steps=world.config.control_interval_steps,
            )

        def fallback(candidate: Any, point: Any) -> PolicyRollouts:
            result = rollout_skill_library(
                params, bundle.spec, candidate, point, bundle.actuator, policy_config
            )
            return PolicyRollouts(
                result.states,
                result.wrenches,
                jnp.all(result.policy_valid, axis=1)
                & jnp.all(jnp.isfinite(result.states), axis=(1, 2)),
            )

        return continuous_version_a_step(
            state,
            nominal,
            fallback,
            obstacles,
            model,
            bundle.actuator,
            safety,
            barrier,
            VersionAFilterConfig(),
            runtime,
            previous_policy_index=previous,
            selection_config=SelectionConfig(switch_score_margin=0.0),
        )

    return controller


def _minimum_segment_clearance(states: np.ndarray, centers: np.ndarray, radii: np.ndarray) -> float:
    if len(radii) == 0:
        return float("inf")
    relative = states[:, None, :3] - centers
    delta = np.diff(relative, axis=0)
    fraction = np.clip(
        -np.sum(relative[:-1] * delta, axis=-1) / np.maximum(np.sum(delta * delta, axis=-1), 1e-30),
        0,
        1,
    )
    return float(
        np.min(np.linalg.norm(relative[:-1] + fraction[..., None] * delta, axis=-1) - radii)
    )


def _append_terminal_record(records: dict[str, list[Any]], state: np.ndarray) -> None:
    """Retain the final executed state while carrying the last real prediction as stale data.

    A separate recorded_control_valid mask labels this row as playback/terminal accounting;
    it is never counted as a new command, learner update, timing sample, or task arrival.
    """
    if not records["position"]:
        raise ValueError("terminal padding requires at least one executed control record")
    for values in records.values():
        values.append(values[-1])
    records["position"][-1] = np.asarray(state[:3]).copy()
    records["quaternion_xyzw"][-1] = np.asarray(state[3:7]).copy()
    records["full_state"][-1] = np.asarray(state).copy()
    for name in ("controller_seconds", "learner_seconds"):
        records[name][-1] = 0.0
    records["missed_deadline"][-1] = False


def run_navigation_experiment(
    world: NavigationWorld,
    config: NavigationExperimentConfig,
    checkpoint: Path,
    directory: Path,
    *,
    device: Any = None,
    opportunity_schedule: DeterministicUpdateSchedule | None = None,
    progress_callback: Any = None,
) -> OnlineConstantWindResult:
    """Run a paired world, censor progress at collision, and retain reproducible learner inputs."""
    config.validate(world)
    directory.mkdir(parents=True, exist_ok=False)
    device = device or jax.devices()[0]
    bundle = load_learner_checkpoint(checkpoint, device=device)
    if not bundle.config.model_compensation:
        raise ValueError("principal navigation checkpoints must keep compensation on throughout")
    if config.learner_kind == "reference":
        from crazyflow.safety.da_plcbf.state_conditioned_learning import (
            build_reference_skill_learner_from_checkpoint,
            save_reference_contract,
        )

        bundle, contract, learner = build_reference_skill_learner_from_checkpoint(
            checkpoint, device=device
        )
        save_reference_contract(contract, directory / "nominal_reference")
        save_reference_contract(contract, directory / "snapshots/nominal_reference")
    else:
        contract = None
        learner = build_persistent_skill_learner(
            bundle.spec, bundle.actuator, bundle.config, device=device
        )
    count = round(world.config.duration_seconds / world.config.control_period)
    schedule = opportunity_schedule or DeterministicUpdateSchedule.periodic(
        count,
        first=round(config.learning_start_seconds / world.config.control_period),
        every=config.update_every_controls,
    )
    if len(schedule.opportunities) != count:
        raise ValueError("opportunity schedule must span exactly the experiment")
    # The endpoint at duration is a recorded state, not an additional control opportunity.
    times = np.arange(count + 1) * world.config.control_period
    (directory / "world.json").write_text(json.dumps(world.metadata(), indent=2) + "\n")
    (directory / "config.json").write_text(json.dumps(asdict(config), indent=2) + "\n")
    (directory / "schedule.json").write_text(json.dumps(schedule.metadata(), indent=2) + "\n")
    base = bundle.point_model
    controller = build_navigation_controller(world, bundle, config)
    plant = jax.jit(lambda x, u, m: direct_wrench_symplectic_step(x, u, m, world.config.dt))
    estimator_config = PointWindEstimatorConfig(response_rate=config.estimator_response_rate)
    estimate = jax.jit(
        lambda e, x, y, u, known: (
            update_point_wind_estimator(
                e, x, y, u, known, dt=world.config.dt, config=estimator_config
            ).state
        )
    )
    methods, summaries, raw, dense, probe_snapshots = {}, {}, {}, {}, {}
    for method in ("fixed", "adaptive"):
        records = _empty_method_records()
        persistent = bundle.state
        state = jax.device_put(jnp.asarray(world.initial_state, dtype=jnp.float32), device)
        previous = jax.device_put(jnp.asarray(-1, dtype=jnp.int32), device)
        estimator = initialize_point_wind_estimator()
        progress = WaypointProgress()
        states, goals, waypoint_indices, active, boundaries = [np.asarray(state)], [], [], [], []
        local_raw = {
            key: []
            for key in (
                "hard",
                "smooth",
                "candidate_valid",
                "point_wind",
                "actual_wind",
                "actual_mass",
                "actual_inertia",
                "candidate_wrenches",
                "selected_index",
                "applied_operational_margin",
                "applied_operational_residual",
                "finite_update",
            )
        }
        encounters, snapshots, controller_seconds, learner_seconds = [], [], [], []
        first_diagnosis_saved = False
        last_update_metrics = None
        pending = None
        last_training_time = 0.0
        warm_model = world.dynamics_at(0, base).model
        warm_goal = jax.device_put(
            jnp.asarray(progress.active_goal(world), dtype=jnp.float32), device
        )
        warm_prediction = world.obstacle_prediction(0, horizon=bundle.config.horizon)
        # Compile the actual controller/plant/learner dataflow before recording service samples.
        warm_state, warm_previous = state, previous
        warm_learning = persistent
        for _ in range(3):
            decision = jax.block_until_ready(
                controller(
                    warm_state,
                    warm_learning.params,
                    warm_model,
                    warm_prediction,
                    warm_previous,
                    warm_goal,
                )
            )
            for _ in range(world.config.control_interval_steps):
                warm_state = plant(warm_state, decision.action, warm_model)
            if method == "adaptive" and config.enable_learning:
                warm_learning, _ = jax.block_until_ready(
                    learner.step(warm_learning, warm_state, warm_model)
                )
            warm_previous = decision.selected_index
        for index, when in enumerate(times):
            prior_snapshot = persistent
            if pending is not None:
                persistent, last_update_metrics, last_training_time = pending
                pending = None
            if progress.termination is not None:
                # Padding serves synchronized playback only. No controls, learning, arrivals,
                # or success credit are generated after the declared terminal boundary.
                _append_terminal_record(records, np.asarray(state))
                for values in local_raw.values():
                    values.append(values[-1])
                local_raw["finite_update"][-1] = False
                goals.append(goals[-1])
                waypoint_indices.append(min(progress.completed, len(world.waypoint_positions) - 1))
                active.append(False)
                continue
            active.append(True)
            dynamics = world.dynamics_at(float(when), base)
            actual_model = jax.device_put(dynamics.model, device)
            model = (
                actual_model
                if config.model_information == "oracle"
                else model_with_point_wind(actual_model, estimator)
            )
            prediction = world.obstacle_prediction(float(when), horizon=bundle.config.horizon)
            goal = jax.device_put(
                jnp.asarray(progress.active_goal(world), dtype=jnp.float32), device
            )
            goals.append(np.asarray(goal))
            waypoint_indices.append(progress.completed)
            started = time.perf_counter()
            decision = jax.block_until_ready(
                controller(state, persistent.params, model, prediction, previous, goal)
            )
            service = time.perf_counter() - started
            controller_seconds.append(service)
            gradient = (
                float(last_update_metrics.gradient_norm) if last_update_metrics is not None else 0.0
            )
            update_norm = (
                float(last_update_metrics.parameter_update_norm)
                if last_update_metrics is not None
                else 0.0
            )
            _append_method_record(
                records,
                state,
                decision,
                library_version=int(persistent.library_version),
                cumulative_gradient_steps=int(persistent.cumulative_gradient_steps),
                diversity_loss=0.0,
                descriptor_target_loss=0.0,
                gradient_norm=gradient,
                parameter_update_norm=update_norm,
                estimated_wind=model.wind_velocity,
                snapshot_age_seconds=float(when - last_training_time),
                controller_seconds=service,
            )
            encounter = nominal_encounter_metrics(
                np.asarray(decision.candidates.states[0, :, :3]),
                prediction,
                dt=world.config.dt,
                ego_radius=dynamics.ego_radius,
                obstacle_clearance=world.config.obstacle_clearance,
            )
            encounters.append({"time": float(when), **encounter})
            if index % config.probe_every_controls == 0:
                snapshots.append((index, state, model, persistent.params, goal, previous))
            for key, value in {
                "hard": decision.values.values,
                "smooth": decision.smooth_values,
                "candidate_valid": decision.candidates.valid,
                "point_wind": model.wind_velocity,
                "actual_wind": actual_model.wind_velocity,
                "actual_mass": actual_model.mass,
                "actual_inertia": actual_model.inertia,
                "candidate_wrenches": decision.candidates.wrenches,
                "selected_index": decision.selected_index,
                "applied_operational_margin": decision.applied_held_operational_margin,
                "applied_operational_residual": decision.applied_held_operational_residual,
            }.items():
                local_raw[key].append(np.asarray(value))
            diagnosis = not first_diagnosis_saved and (
                float(np.max(decision.values.values)) < 0 or bool(decision.degraded)
            )
            if method == "adaptive" and (
                index % config.save_periodic_snapshots_controls == 0 or diagnosis
            ):
                for label, snapshot in (
                    (("published", persistent), ("previous", prior_snapshot))
                    if diagnosis
                    else (("published", persistent),)
                ):
                    save_learner_checkpoint(
                        snapshot,
                        bundle.spec,
                        bundle.config,
                        bundle.actuator,
                        state,
                        directory / f"snapshots/{index:04d}-{label}",
                        metadata={
                            "simulation_time": float(when),
                            "previous_policy_index": int(previous),
                            "goal_for_external_replay_only": np.asarray(goal).tolist(),
                            "point_wind_for_external_replay": np.asarray(
                                model.wind_velocity
                            ).tolist(),
                            "reason": "first_degraded_or_negative" if diagnosis else "periodic",
                        },
                    )
                first_diagnosis_saved |= diagnosis
            training_state = state
            interval_states = [np.asarray(state)]
            for _ in range(world.config.control_interval_steps):
                following = plant(state, decision.action, actual_model)
                if config.model_information == "estimated":
                    estimator = estimate(estimator, state, following, decision.action, actual_model)
                state = following
                interval_states.append(np.asarray(state))
                states.append(np.asarray(state))
            jax.block_until_ready((state, estimator))
            previous = decision.selected_index
            physical_clearance = _minimum_segment_clearance(
                np.asarray(interval_states),
                np.asarray(prediction.centers[: world.config.control_interval_steps + 1]),
                world.obstacle_radii + dynamics.ego_radius,
            )
            progress = advance_waypoints(
                world,
                progress,
                np.asarray(state[:3]),
                float(when + world.config.control_period),
                physical_collision=physical_clearance <= 0,
            )
            update_seconds, finite = 0.0, False
            if (
                method == "adaptive"
                and config.enable_learning
                and schedule.opportunities[index]
                and progress.termination is None
            ):
                started = time.perf_counter()
                changed, metrics = jax.block_until_ready(
                    learner.step(persistent, training_state, model)
                )
                update_seconds = time.perf_counter() - started
                learner_seconds.append(update_seconds)
                finite = bool(metrics.finite_update_applied)
                pending = changed, metrics, float(when)
                records["diversity_loss"][-1] = float(metrics.loss.diversity)
                records["descriptor_target_loss"][-1] = float(metrics.loss.descriptor_target)
            local_raw["finite_update"].append(finite)
            records["learner_seconds"][-1] = update_seconds
            records["missed_deadline"][-1] = service + update_seconds > world.config.control_period
            boundaries.append(
                {
                    "time": float(when),
                    "version_used": int(persistent.library_version),
                    "update_launched": update_seconds > 0,
                    "finite": finite,
                    "completed_version": int(pending[0].library_version) if pending else None,
                    "controller_seconds": service,
                    "learner_seconds": update_seconds,
                    "physical_clearance_m": physical_clearance
                    if np.isfinite(physical_clearance)
                    else None,
                }
            )
            if progress_callback and index % 100 == 0:
                progress_callback(method, index, count, progress.completed)
        method_trace = replace(
            _method_trace(records),
            goal_position=np.asarray(goals),
            waypoint_index=np.asarray(waypoint_indices),
            recorded_control_valid=np.asarray(active),
            physical_collision_recorded=(
                ~np.asarray(active) & (progress.termination == "physical_collision")
            ),
        )
        methods[method] = method_trace
        probe_snapshots[method] = snapshots
        dense[method] = np.asarray(states)
        execution_audit, actual_operational_margins = audit_navigation_execution(
            dense[method], method_trace, world
        )
        raw[f"{method}_actual_operational_margins"] = actual_operational_margins
        for key, values in local_raw.items():
            raw[f"{method}_{key}"] = np.asarray(values)
        raw[f"{method}_active_control"] = np.asarray(active)
        all_centers, _ = world.obstacle_kinematics(np.arange(len(states)) * world.config.dt)
        clearance = _minimum_segment_clearance(
            np.asarray(states), all_centers, world.obstacle_radii + world.config.ego_radius
        )
        mask = np.asarray(active)
        blocked = np.asarray([row["nominal_blocked"] for row in encounters], dtype=bool)
        summaries[method] = {
            "waypoints_completed": progress.completed,
            "waypoints_total": len(world.waypoint_positions),
            "termination": progress.termination,
            "termination_time_seconds": progress.termination_time_seconds,
            "arrival_times_seconds": progress.arrival_times_seconds,
            "physical_collision": progress.termination == "physical_collision",
            "minimum_physical_clearance_m": clearance if np.isfinite(clearance) else None,
            "minimum_inflated_clearance_m": clearance - world.config.obstacle_clearance
            if np.isfinite(clearance)
            else None,
            "active_controls": int(np.sum(mask)),
            "degraded_controls": int(np.sum(method_trace.degraded[mask])),
            "accepted_qp_controls": int(np.sum(method_trace.qp_valid[mask])),
            "executed_positive_policy_dual_controls": int(
                np.sum(method_trace.executed_policy_dual[mask] > 1e-7)
            ),
            "emergency_controls": int(np.sum(method_trace.used_emergency[mask])),
            "finite_updates": int(np.sum(np.asarray(local_raw["finite_update"])[mask])),
            "controller_service": _timing_statistics(controller_seconds),
            "learner_service": _timing_statistics(learner_seconds),
            "service_exceeds_nominal_period_count": int(np.sum(method_trace.missed_deadline[mask])),
            "nominal_blocked_fraction": float(np.mean(blocked)),
            "separate_nominal_encounter_episodes": int(
                np.sum(blocked & ~np.r_[False, blocked[:-1]])
            ),
            "encounters": encounters,
            "publications_and_inputs": boundaries,
            "execution_audit": execution_audit,
        }
        final_published = pending[0] if pending is not None else persistent
        if method == "adaptive":
            save_learner_checkpoint(
                final_published,
                bundle.spec,
                bundle.config,
                bundle.actuator,
                state,
                directory / "final_adaptive_checkpoint",
                metadata={
                    "terminal_publication": True,
                    "learning_is_censored_at_termination": True,
                },
            )
    # Every pair below shares a state, model, goal, and absolute-time obstacle prediction.
    # Evaluation occurs after execution and never changes the published learner sequence.
    probes, probe_arrays = [], {}
    fixed_params = bundle.state.params
    adaptive_at = {item[0]: item[3] for item in probe_snapshots["adaptive"]}
    for anchor in ("fixed", "adaptive"):
        for index, state, model, _, goal, previous in probe_snapshots[anchor]:
            if index not in adaptive_at:
                # Only compare actually published snapshots before either branch terminates.
                continue
            prediction = world.obstacle_prediction(float(times[index]), horizon=bundle.config.horizon)
            for label, params in (("fixed", fixed_params), ("adaptive", adaptive_at[index])):
                decision = jax.block_until_ready(
                    controller(state, params, model, prediction, previous, goal)
                )
                probes.append(
                    {
                        "time": float(times[index]), "anchor": anchor, "library": label,
                        "fallback_max_hard": float(np.max(decision.values.values[1:])),
                        "augmented_max_hard": float(np.max(decision.values.values)),
                        "eligible_count": int(decision.eligible_candidate_count),
                        "accepted_qp": bool(decision.qp_valid),
                    }
                )
                probe_arrays[f"{index}_{anchor}_{label}_full_states"] = np.asarray(decision.candidates.states)
    np.savez_compressed(directory / "raw_diagnostics.npz", **raw)
    np.savez_compressed(directory / "dense_plant_states.npz", **dense)
    np.savez_compressed(directory / "same_state_probe_trajectories.npz", **probe_arrays)
    centers, _ = world.obstacle_kinematics(times)
    wind_events = tuple(event.time_seconds for event in world.config.wind_events)
    payload = world.config.payload_events[0] if world.config.payload_events else None
    trace = ComparisonVideoTrace(
        time_seconds=times,
        goal_position=world.waypoint_positions[0],
        obstacles=tuple(
            ObstacleTrack(
                centers[:, k],
                float(radius),
                float(radius + world.config.ego_radius + world.config.obstacle_clearance),
                f"moving-{k}",
            )
            for k, radius in enumerate(world.obstacle_radii)
        ),
        true_wind=np.asarray([world.wind_at(t) for t in times]),
        estimated_wind=methods["adaptive"].estimated_wind,
        wind_change_time=wind_events[0] if wind_events else float(times[-1]),
        wind_event_times_seconds=np.asarray(wind_events),
        descriptor_targets=np.asarray(bundle.spec.target_descriptors),
        fixed=methods["fixed"],
        adaptive=methods["adaptive"],
        title=f"3D waypoint navigation · {world.config.obstacle_count} moving obstacles · {config.model_information}",
        left_label="FROZEN LIBRARY · SAME POINT MODEL",
        right_label="PERSISTENT ADAPTATION · SAME POINT MODEL",
        show_wind_change_banner=bool(wind_events),
        drone_radius=world.config.ego_radius,
        drone_model="cf21B_500",
        physical_model_name="cf21B_500",
        payload_attachment_time_seconds=payload.time_seconds if payload else None,
        payload_half_extents=np.asarray(payload.half_extents) if payload else None,
        payload_mass_delta_kg=payload.mass_fraction * float(base.mass) if payload else None,
        payload_base_mass_kg=float(base.mass) if payload else None,
    )
    trace.validate()
    summary = {
        "experiment": "navigation",
        "config": asdict(config),
        "world": world.metadata(),
        "checkpoint": str(checkpoint),
        "checkpoint_sha256": bundle.sha256,
        "compensation_protocol": {"checkpoint": True, "prefix": True, "post_event": True},
        "schedule": schedule.metadata(),
        "methods": summaries,
        "same_state_probes": probes,
        "reference_contract": contract is not None,
        "execution_scope": "deterministic synchronized mechanism replay; measured service reported, no real-time deadline claim",
        "collision_scope": "swept relative chords at 20 ms integration nodes; accelerated obstacle arcs are not continuously certified",
    }
    result = OnlineConstantWindResult(trace, summary, methods)
    save_online_constant_wind_result(result, directory, stem="navigation_comparison")
    (directory / "SOURCE_SHA256.json").write_text(
        json.dumps(
            {
                str(Path(__file__).relative_to(Path.cwd())): hashlib.sha256(
                    Path(__file__).read_bytes()
                ).hexdigest()
            },
            indent=2,
        )
        + "\n"
    )
    return result
