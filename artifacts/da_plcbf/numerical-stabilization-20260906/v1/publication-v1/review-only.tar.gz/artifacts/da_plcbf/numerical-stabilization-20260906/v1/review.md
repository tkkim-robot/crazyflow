## Overall verdict

**“PD adaptive” is technically valid, but its label is misleading and it should not replace your intended main comparison. The agent also did substantial investigation—not merely a few unsuccessful trials. However, stopping the current experiment batch was justified; stopping method development would be premature because two concrete numerical problems were identified but left unrepaired.**

I reviewed **`c2505574fd75f3949f26b7e05f8db322d963a9e9`** on `actuator-learning-diagnostics`, including the report, handcrafted-library implementation, revised loss, QP acceptance path, and asynchronous learner. This is a source-and-report review; I did not independently rerun the flights or watch the local-only video.

## 1. What “PD adaptive” actually does

**It does not adapt the PD gains.** The implementation uses sixteen handcrafted velocity-and-braking primitives, followed by the shared attitude/rate PD controller and model-aware F2 actuator adapter. Its neural residual is exactly zero. Online BPTT changes only:

| Quantity                                        | Adaptive parameters |
| ----------------------------------------------- | ------------------: |
| Desired-velocity offsets for sixteen primitives |    \(16\times3=48\) |
| Maneuver-duration offsets                       |              \(16\) |
| **Total**                                       |              **64** |

The velocity offsets are bounded by ±0.5 m/s; effective durations are clipped to 0.1–1.2 s. The parameter-update norm is capped at 0.025. The feedback gains and neural weights do not adapt in this arm.

With the zero residual omitted, its behavior command is essentially

$$
a_i
=
a_{\max}\tanh\!\left(
\frac{k_v\bigl[\sigma(t;d_i)(v_i^0+\delta v_i)-v\bigr]}
{a_{\max}}
\right),
$$

where \(v_i^0\) is the handcrafted directional target, \(\delta v_i\) is a learned adjustment, and \(\sigma(t;d_i)\) switches the maneuver toward braking according to its duration. BPTT differentiates the resulting rollout loss with respect to \(\delta v_i\) and \(d_i\). Thus, differentiable simulation is tuning a small parameterized controller rather than a neural network.

A clearer name would be **“BPTT-tuned handcrafted primitives.”**

### Why this arm appeared

It came from **my previous recommendation of a four-way diagnostic**, which included handcrafted frozen/adaptive and learned frozen/adaptive libraries. Therefore, I would not blame the agent for inventing this comparison.

Nevertheless, your intended headline comparison is entirely reasonable:

> **Handcrafted frozen library → learned frozen library → learned adaptive library.**

I recommend restoring that as the main comparison and moving PD adaptation to an auxiliary ablation. It answers whether a neural parameterization is necessary; it is not your proposed neural method.

### Why it does not visibly become more diverse

The selected repaired objective is principally **nominal-teacher motion restoration**, including prefix tracking and braking. It explicitly removes the standalone diversity and pairwise penalties. It does not create additional policies or necessarily widen the trajectory fan. Both PD variants retain sixteen primitives.

Consequently, “the fan does not look broader” does not itself invalidate the implementation. Adaptation could restore a useful braking profile or shift trajectories without increasing their spread.

However, **that also means the current repair is testing a narrower mechanism than unrestricted discovery of a more useful repertoire**. If exact teacher restoration prevents the learner from exploiting alternative feasible behaviors, that would be an objective-design limitation to investigate—not a visualization problem. Your original direction is broader: adapt reusable, obstacle-agnostic behaviors so the runtime filter has useful recovery options. 

## 2. Was the agent’s stopping decision fair?

### It was not an early stop in the sense of “barely tried”

The report accounts for **200 physical attempts** across the original diagnostic protocol, selector amendment, runtime experiments, and secondary union validation. It also investigates component gradients, Adam reset, per-skill braking, same-state command differences, numerical builds, and asynchronous publication. That is meaningful work.

The latest “zero gains and four losses” statement specifically describes **the secondary `UNION_REFRESH` continuation-versus-onset-freeze experiment**. It is not the aggregate result of every learned-adaptation experiment.

For the earlier fresh-world experiment, the paired task results were:

| Initialization and condition             | Adaptation-only successes | Freeze-only successes |
| ---------------------------------------- | ------------------------: | --------------------: |
| Learned library, effectiveness fault     |                     **1** |                 **0** |
| Learned library, no change               |                         0 |                 **2** |
| Handcrafted library, effectiveness fault |                         1 |                 **4** |
| Handcrafted library, no change           |                     **3** |                     0 |

These are eight-world, single-library-seed comparisons, not broad statistical conclusions. They show conditional benefits and regressions—not uniformly useless learning.

Stopping the separately sealed forty-flight union-validation experiment at its declared endpoint was appropriate. Continuing to add favorable cases to the same validation set would weaken the evidence.

### But stopping development here would be premature

**The report itself identifies specific implementation-level repairs that were not attempted.** That is a much stronger reason to continue than simply believing that the method ought to work.

The appropriate conclusion is:

> This repair did not generalize. Preserve the result, close that experiment, and begin a new development iteration addressing the diagnosed defects.

It is **not**:

> Learned adaptation is fundamentally worse, so there is nothing useful left to investigate.

## 3. The most important unresolved findings

### A. The learner can update because identical teacher and student computations disagree numerically

This is the highest-priority learning issue.

In the selected no-change PD diagnostic, the teacher and student begin with identical parameters, models, and configurations, and zero Adam history. Nevertheless, the production computation produces:

* loss approximately \(1.91\times10^{-8}\);
* gradient norm approximately \(1.19\times10^{-4}\);
* first parameter-update norm approximately **0.00791**.

The audit finds that matched teacher/student computation paths produce identical rollouts, whereas different batching and constant-versus-dynamic argument paths produce small discrepancies. Using the identical stopped-gradient rollout as reference gives zero loss and zero gradients. **The proposed production repair—matching those computation paths—has not been implemented.**

The current code still computes the student through a batched rollout, the current-state teacher separately, and anchor teachers through a cached path. The \(10^{-6}\) loss dead zone is insufficient for the discrepancies observed in the audit.

**This is not legitimate adaptation to a dynamics change. It is a spurious optimization signal.** It does not prove that every failure or nominal success is caused by numerical drift, but it must be removed before those effects are interpreted confidently.

The repair should preserve the genuine fixed nominal teacher and stop-gradient semantics. It should not hard-code zero loss whenever the model appears unchanged, nor reject policy updates based on their safety outcomes.

### B. QP solver acceptance and final execution checks use inconsistent residual scales

The recorded PD decision exposes another concrete issue. The audit reports a normalized-coordinate row norm of approximately **58.10**. A solver tolerance of \(2\times10^{-6}\) can therefore correspond to approximately \(1.16\times10^{-4}\) in raw row-residual units, while the final execution check still requires a raw residual above \(-2\times10^{-6}\). The float32 spacing of the bound is itself approximately \(3.81\times10^{-6}\).

The code confirms that the command-coordinate QP is followed by the separate check

```python
bound - row @ result.action >= -config.tolerance
```

and that sequential refinement is triggered by operational-check failure—not merely this policy-row rejection.

This provides a plausible route from a tiny numerical difference to a discrete QP-to-emergency switch. The reported PD comparison exhibits such a switch and changes from success to collision across numerical executions. However, the rejected QP command and its exact residual were not saved, so **the precise cause of that rejection is not yet conclusively established**.

**The next action should be to capture and repair this numerical path—not merely archive another compiler-sensitive outcome.**

Use consistent constraint scaling, a roundoff-aware inward feasibility margin, and rechecking after conversion to the executed command representation. Retain the physical constraints and nonlinear held checks; do not obtain success by broadly loosening safety tolerances.

### C. Improved repertoire metrics still do not imply improved executed control

The branch now demonstrates this distinction clearly. At one common state, adaptation improves the highest fallback hard value and the braking of that best-value fallback, but the actual selector chooses another policy. In the union, hysteresis retains an adapted policy even though an immutable original policy has a slightly higher volume score.

The attempted incumbent-refresh heuristic repairs some development outcomes but harms another; its subsequent union validation yields no gains and four losses. **Therefore, simply resetting the selected index is not a validated solution.**

This also qualifies my earlier union suggestion. Adding frozen policies preserves pointwise maximum coverage, but does not force the controller to reproduce the safer frozen trajectory. The union experiment was useful precisely because it exposed this gap.

### D. Asynchronous learning now works, but the complete execution contract still needs attention

The worker genuinely maintains persistent optimizer state and publishes immutable completed snapshots. The measured adaptive runs obtain **59 learned-library publications and 257 PD publications**, resolving the earlier zero-update problem for these asynchronous executions.

However, measured command holds reach approximately **50–55 ms**, although the sensing period and nominal held-command checks use 40 ms. Passing a controller-service deadline does not establish that the physical hold stayed within the modeled duration.

That does not automatically explain the collisions, but it limits the interpretation of the safety checks. Scheduling, application latency, and the interval actually certified need to be aligned before claiming deployable adaptive safety.

## 4. What should be done next?

**I would not request another large scenario campaign yet. I would request a focused numerical-stabilization and causal re-evaluation iteration.**

### First: repair the two identified numerical paths

For the learner, match teacher/student batching and argument treatment, then test the **actual fused loss-and-update executable**, not only a separately compiled diagnostic. With identical teacher/student behavior and zero optimizer momentum, there should be no meaningful parameter drift. Separately test the production persistent-Adam case, where existing momentum can legitimately produce movement.

For the QP, record the rejected command, solver branch, row scales, solver residuals, executed-precision residual, and rejection reason. Implement a bounded inward correction or consistent numerical formulation and verify it across fresh builds and small perturbations.

Neither task requires abandoning your architecture.

### Second: restore the primary three-method comparison

Use the same scenes and shared low-level adapter for:

| Main method            | Purpose                                                         |
| ---------------------- | --------------------------------------------------------------- |
| **Handcrafted frozen** | Measures what a competent designed repertoire already provides. |
| **Learned frozen**     | Isolates the value of the learned repertoire.                   |
| **Learned adaptive**   | Isolates the additional effect of online adaptation.            |

Keep **PD parameter adaptation and unions as secondary ablations**. For post-fault attribution, retain the extra onset-freeze control; it answers a different question from startup-frozen deployment.

The video should reflect this hierarchy. It need not become more elaborate.

### Third: re-evaluate known positive, negative, and no-change cases before fresh validation

Use a small fixed development set containing the harmful effectiveness case, the existing learned fault-cell gain, and a no-change regression. Cross **old/new learner numerics** with **old/new QP numerics** so that a changed result can be attributed to a particular repair.

Preserve the old results. A successful numerical repair is a new implementation result, not a reason to rewrite the previous record.

### Fourth: only then decide whether the learning objective needs a larger revision

The braking repair improves fixed-bank competence but still fails the historical harmful flight. That is real evidence that passing a small behavior bank is insufficient.

If the corrected implementation still improves tracking while harming control, I would investigate **which behavior changes alter the selected certificate and its gradient**, rather than simply increase a diversity coefficient. A later objective could preserve skill identity while allowing a range of acceptable trajectories, instead of rigidly reproducing the nominal teacher. That is a proposed direction, not an established remedy.

## Bottom line

**Your concern about the presentation is justified: PD adaptation is an auxiliary parameter-tuning experiment, not the main learned-adaptive method, and it should be labeled accordingly. Its inclusion came from my earlier recommendation, not arbitrary scope expansion by the agent.**

**The agent was also justified in rejecting the latest union repair after its prescribed validation failed. But the project should not stop at that result: it has now exposed two actionable numerical defects and an execution-timing limitation that deserve implementation and testing.**

The next instruction should require **repairing those identified mechanisms and re-evaluating their causal effects**, rather than either accepting another negative summary as the endpoint or tuning scenarios indefinitely until a favorable video appears.
