import json,os,subprocess,tempfile
from pathlib import Path
base=Path(__file__).resolve().parent
root=base.parents[3]
python=root/'.pixi/envs/gpu-tests/bin/python'
protocol=base/'sealed-v2/protocol.json'
phases=[]
for label,mode in [('fresh-build-1','probe'),('fresh-build-2','probe'),('development-36','flights')]:
    cache=tempfile.mkdtemp(prefix='crazyflow-stabilization-'+label+'-')
    env={**os.environ,'PYTHONPATH':str(root),'SCIPY_ARRAY_API':'1','XLA_PYTHON_CLIENT_PREALLOCATE':'false',
         'JAX_COMPILATION_CACHE_DIR':cache,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'}
    env.pop('JAX_PLATFORMS',None)
    env.pop('CUDA_VISIBLE_DEVICES',None)
    cmd=[str(python),'-m','benchmark.da_plcbf_numerical_stabilization',mode,'--protocol',str(protocol),'--output',str(base/label)]
    row={'label':label,'command':cmd,'cache':cache,'cache_empty_before':not any(Path(cache).iterdir()),'status':'running'}
    phases.append(row)
    (base/'execution.json').write_text(json.dumps(phases,indent=2)+'\n')
    with (base/(label+'.log')).open('w') as log:
        result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    row.update(exit_code=result.returncode,status='finished')
    (base/'execution.json').write_text(json.dumps(phases,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
